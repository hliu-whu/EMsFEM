
[x,y]=meshgrid(0:0.01:1,0:0.01:1);
d0=ones(size(x,1)*size(x,2),1);
for ie = 1:length(Element)
    node_id = Element{ie,1};
    pv = [Node(node_id,1),Node(node_id,2);Node(node_id(1),1),Node(node_id(1),2)];
    d1 = dpoly([x(:),y(:)],pv);
    d0 = dunion(d0,d1);
end
d = reshape(d0,size(x,1),size(x,2));
rmin=1.8;
[dy,dx] = meshgrid(-ceil(rmin)+1:ceil(rmin)-1,-ceil(rmin)+1:ceil(rmin)-1);
H = max(0,rmin-sqrt(dx.^2+dy.^2))/sum(sum(max(0,rmin-sqrt(dx.^2+dy.^2))));
dfiltered = imfilter(d,H, 'same');

t = 0.022;
tfiltered=0.0215;

figure; surf(x,y,d+t,'EdgeColor','none'); axis equal;view(0,90); colorbar;
figure; C=contourf(x,y,d+t,[0 0]); axis equal;

figure; surf(x,y,dfiltered+t,'EdgeColor','none'); axis equal;view(0,90); colorbar;
figure; C=contourf(x,y,dfiltered+tfiltered,[0 0]); axis equal;

vol1=microstructure_density(x,d+t);
vol2=microstructure_density(x,dfiltered+tfiltered);
% grid minor
% set(gca,'xgrid','on','ygrid','on','MinorGridAlpha',1,'LineWidth',1.5);