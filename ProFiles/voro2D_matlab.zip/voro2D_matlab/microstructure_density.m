function vol =  microstructure_density(x,pp)

nely = size(x,1)-1;
nelx = size(x,2)-1; 
eleN1 = repmat((1:nely)',1,nelx)+kron(0:nelx-1,(nely+1)*ones(nely,1));
eleNode = repmat(eleN1(:),1,4)+repmat([0,nely+[1,2],1],nelx*nely,1);

% dd=d+0.02222;
[s,t] = meshgrid(-1:0.4:1,-1:0.4:1);
        tmpPhi = (1-s(:)).*(1-t(:))/4*pp(eleNode(:,1))'+(1+s(:)).*(1-t(:))/4*...
        pp(eleNode(:,2))'+(1+s(:)).*(1+t(:))/4*pp(eleNode(:,3))'+...
        (1-s(:)).*(1+t(:))/4*pp(eleNode(:,4))'; 
        eleVol = sum(tmpPhi>=0,1)'/numel(s);
        vol = sum(eleVol)/(nelx*nely);
end