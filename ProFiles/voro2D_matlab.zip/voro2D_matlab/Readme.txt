
主程序test01.mlx，程序主要功能是生成二维维诺型结构
工作区变量vol1和vol2分别代表未平滑处理和已平滑处理结构的体积分数

结果文件为Grid_info23.o.mesh和Grid_info23.inp


The main script test01.mlx is used to generate 2D Voronoi structures.
The workspace variables vol1 and vol2 represent the volume fractions of the unsmoothed and smoothed structures, respectively.

The output files are Grid_info23.o.mesh and Grid_info23.inp.